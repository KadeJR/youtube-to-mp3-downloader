title "setup part 2 for youtube downloader script by Kade Rabe"

echo "setup part 2 for youtube downloader script by Kade Rabe"

pip install blessed

pip install pytube