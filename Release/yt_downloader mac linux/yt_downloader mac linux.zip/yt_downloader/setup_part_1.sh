title "setup part 1 for youtube downloader script by Kade Rabe"

echo "setup part 1 for youtube downloader script by Kade Rabe"

curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py

python3 get-pip.py

