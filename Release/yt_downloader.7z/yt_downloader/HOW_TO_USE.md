# How to use

to use download python from the python website here https://www.python.org/downloads/

make sure the yt_downloader folder stays on your desktop

after python has been succesfully installed run the setup_part_1.bat and setup_part_2.bat scripts in order

to run the app now run yt_downloader.bat