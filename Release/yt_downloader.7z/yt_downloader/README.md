# youtube-to-mp3-downloader
quick Youtube video downloader written in python, that takes in a playlist link and downloads all the videos as mp3 into a new folder
